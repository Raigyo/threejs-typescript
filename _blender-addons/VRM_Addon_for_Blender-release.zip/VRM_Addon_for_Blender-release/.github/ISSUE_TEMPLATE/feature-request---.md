---
name: Feature request:要望
about: Suggest an idea for this project:要望向けテンプレ
title: Feature request:要望
labels: ''
assignees: ''

---

**Is your feature request related to a problem? Please describe.:バグじゃないけどアドオンの動作でなにか困ってることがあれば**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like:どう動いてほしいかをどうぞ**
A clear and concise description of what you want to happen.

**Describe alternatives you've considered:他にこんなんでもいいよ、というのがあれば**
A clear and concise description of any alternative solutions or features you've considered.

**Additional context::なんかほかに書きたいことがあれば**
Add any other context or screenshots about the feature request here.
