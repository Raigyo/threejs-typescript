from . import credits_menu
from . import main_menu
from . import properties_menu
from . import update_menu
