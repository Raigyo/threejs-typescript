# -*- coding: utf-8 -*-

# Module for custom exceptions

class MaterialNotFoundError(Exception):
    pass

class DivisionError(Exception):
    pass
